<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Paths" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="../animation/Sprout Lands - Sprites - Basic pack/Objects/Paths.png" width="64" height="64"/>
</tileset>
