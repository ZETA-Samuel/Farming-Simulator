<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Hills" tilewidth="16" tileheight="16" tilecount="99" columns="11">
 <image source="../animation/Sprout Lands - Sprites - Basic pack/Tilesets/Hills.png" width="176" height="144"/>
</tileset>
